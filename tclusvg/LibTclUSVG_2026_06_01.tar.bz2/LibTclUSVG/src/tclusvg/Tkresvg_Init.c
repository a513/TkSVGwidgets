#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tcl.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "resvg.h"


/*
//В некоторых Linux этой функции может не быть
unsigned long getauxval (unsigned long t) {
    t = 10;
    return 0;
}
*/

/*Вид подфункций в пакете*/
typedef int ((*subProc)(ClientData, Tcl_Interp*));
/*Структура подфункций*/
typedef struct {
    char*	subname; //Имя подфункции
    subProc	f; //Адрес функции
    int		minStack; //Количество параметров
} subEntry;

/* Главная процедура */
static int resvgwrapCmd(ClientData dummy, Tcl_Interp* interp, int argc, char** argv)
{
    char *out_xml = NULL;
    resvg_options *opt = NULL;
    resvg_render_tree *tree;
    int err;
    resvg_size size;
    int width = 0;
    int height = 0;
    char xmlfrom[5];
    char xmlsize[5];
    strcpy(xmlfrom, "file");
    strcpy(xmlsize, "none");

    if (argc < 2)
    {
	char er[1024];
//        printf("Usage: tclusvg usvg <string svg-xml> [-size ]\n");
	sprintf(er, "Package version Usvg: %s\nUsage: tclusvg <svg-xml> [[-file | -data] | -size]", PACKAGE_VERSION);

    	Tcl_SetResult(interp, er, (Tcl_FreeProc*)0);
    	return TCL_OK;
    }

    opt = resvg_options_create();
    resvg_options_load_system_fonts(opt);


    resvg_options_set_serif_family(opt, "Times New Roman");
    resvg_options_set_sans_serif_family(opt, "Arial");
    resvg_options_set_cursive_family(opt, "Comic Sans MS");
    resvg_options_set_fantasy_family(opt, "Impact");
    resvg_options_set_monospace_family(opt, "Courier New");

    // Optionally, you can add some CSS to control the SVG rendering.
    resvg_options_set_stylesheet(opt, "svg { fill: black; }");

    if (argc > 2) {
	int i = 2;
	while (i < argc) {
	    if (!strcmp(argv[i], "-size")) {
		    strcpy(xmlsize, "size");
	    } else if (!strcmp(argv[i], "-data")) {
		    strcpy(xmlfrom, "data");
	    } else if (!strcmp(argv[i], "-file")) {
		    strcpy(xmlfrom, "file");
	    } else {
		    Tcl_AppendResult(interp, "Bag params: ", argv[i], 0);
		    return TCL_ERROR;
	    }
	    i++;
	}
    }
    
    // Construct a tree from the svg file and pass in some options
    if (!strcmp(xmlfrom, "file")) {
	err = resvg_parse_tree_from_file(argv[1], opt, &tree);
    } else {
	err = resvg_parse_tree_from_data(argv[1], strlen(argv[1]), opt, &tree);
    }
    resvg_options_destroy(opt);
    if (err != RESVG_OK)
    {
//        printf("Error id: %i\n", err);
	Tcl_AppendResult(interp, "Bag parse: ", argv[1], 0);
	return TCL_ERROR;
    }

    if (strcmp(xmlsize, "size") == 0) {
	size = resvg_get_image_size(tree);
	char er[1024];
	width = (int)size.width;
	height = (int)size.height;
	sprintf(er, "%i %i", width, height);
//fprintf (stderr, "Size: =%s\n", er);
	Tcl_SetObjResult(interp, Tcl_NewStringObj(er, -1));
	return TCL_OK;
    }

//fprintf (stderr, "Version=%s\n", resvg_version_string());

    resvg_tree_to_xml(tree, &out_xml);

    Tcl_SetObjResult(interp, Tcl_NewStringObj(out_xml, -1));

    resvg_free_string (out_xml);

    return TCL_OK;
    
}

int Tclusvg_Init(Tcl_Interp *interp) {
    if (Tcl_InitStubs(interp, TCL_VERSION, 0) == NULL) {
	return TCL_ERROR;
    }
     /* changed this to check for an error - GPS */
    if (Tcl_PkgProvide(interp, "tclusvg", PACKAGE_VERSION) == TCL_ERROR) {
        return TCL_ERROR;
    }

    Tcl_CreateCommand(interp, "tclusvg", (Tcl_CmdProc *)resvgwrapCmd, (ClientData) 0, (void (*)()) NULL);
    return TCL_OK;
}
